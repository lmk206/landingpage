<?
    include_once
    $_SERVER["DOCUMENT_ROOT"]."/admin/head.php";
    page('contact/list.php');
?>

<?
    include_once
    $_SERVER["DOCUMENT_ROOT"]."/admin/foot.php";
?>