<?

include_once
    $_SERVER["DOCUMENT_ROOT"]."/admin/head.php";

?>
<!--보-->

<?
include_once
    
    $_SERVER["DOCUMENT_ROOT"]."/admin/foot.php";

?>