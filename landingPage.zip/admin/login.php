<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>

  <form action="login_ok.php" method="post">
      
      <input type="text" name="id">
      <input type="password" name="pw">
      <input type="submit" value="Login">
      
      <!-- 관리자라면 session을 이용하게끔 설정 -->
  </form>

            
</body>
</html>